module.exports = {
  compact: false,
  presets: [
    '@vue/cli-plugin-babel/preset'
  ]
}
